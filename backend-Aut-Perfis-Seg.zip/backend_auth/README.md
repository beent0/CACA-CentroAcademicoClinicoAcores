# Backend CACA — Autenticação, Perfis e Segurança

## Estrutura de Pastas

```
backend_auth/
├── server.js                               ← ponto de entrada
├── package.json
├── .env.example                            ← copia para .env
├── config/
│   └── db.js                               ← ligação ao MongoDB
│
├── autenticacao/                           ── MÓDULO 1
│   ├── models/User.js                      ← esquema (nome, email, telemovel, role, bio)
│   ├── controllers/authController.js       ← register, login, getProfile, updateProfile
│   └── routes/auth.js                      ← POST /api/auth/register|login
│
├── perfis_permissoes/                      ── MÓDULO 2
│   ├── middleware/auth.js                  ← protect (JWT) + adminOnly (role)
│   ├── controllers/adminController.js      ← getUsers, changeRole, deleteUser
│   └── routes/admin.js                     ← /api/admin/users
│
└── seguranca/                              ── MÓDULO 3
    ├── middleware/security.js              ← rate limiting (anti brute force)
    └── config/securityConfig.js           ← CORS (porta 5173) + validação .env
```

---

## Endpoints da API

### Autenticação
| Método | Rota | Auth |
|--------|------|------|
| POST | `/api/auth/register` | ❌ |
| POST | `/api/auth/login` | ❌ |

### Perfil
| Método | Rota | Auth |
|--------|------|------|
| GET | `/api/users/profile` | ✅ JWT |
| PUT | `/api/users/profile` | ✅ JWT |

### Administração (apenas admins)
| Método | Rota | Auth |
|--------|------|------|
| GET | `/api/admin/users` | ✅ JWT + admin |
| PUT | `/api/admin/users/:id/role` | ✅ JWT + admin |
| DELETE | `/api/admin/users/:id` | ✅ JWT + admin |

---

## Como Correr

```bash
cp .env.example .env
npm install
npm run dev
```
