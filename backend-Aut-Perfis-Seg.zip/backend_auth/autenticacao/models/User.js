const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

/**
 * User schema.
 * Campos: nome, email, telemovel, password (hash), role, bio
 * role: 'regular' (default) | 'admin'
 */
const userSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome é obrigatório'],
    trim: true,
    minlength: [2, 'O nome deve ter pelo menos 2 caracteres'],
  },
  email: {
    type: String,
    required: [true, 'O email é obrigatório'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Email inválido'],
  },
  telemovel: {
    type: String,
    default: '',
    trim: true,
  },
  password: {
    type: String,
    required: [true, 'A palavra-passe é obrigatória'],
    minlength: [6, 'A palavra-passe deve ter pelo menos 6 caracteres'],
    select: false, // nunca devolvida nas queries por defeito
  },
  role: {
    type: String,
    enum: ['regular', 'admin'],
    default: 'regular',
  },
  bio: {
    type: String,
    default: '',
    maxlength: [300, 'A bio não pode ter mais de 300 caracteres'],
  },
}, { timestamps: true });

// Hash da password antes de guardar (apenas se foi modificada)
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

/**
 * Compara a password em texto simples com o hash guardado.
 * @param {string} candidata
 * @returns {Promise<boolean>}
 */
userSchema.methods.comparePassword = function (candidata) {
  return bcrypt.compare(candidata, this.password);
};

module.exports = mongoose.model('User', userSchema);
