const express = require('express');
const router  = express.Router();
const { body } = require('express-validator');
const { register, login } = require('../controllers/authController');

// Regras de validação para o registo
const regrasRegisto = [
  body('nome').trim().notEmpty().withMessage('O nome é obrigatório'),
  body('email').isEmail().withMessage('Email inválido').normalizeEmail(),
  body('password')
    .isLength({ min: 6 })
    .withMessage('A palavra-passe deve ter pelo menos 6 caracteres'),
];

// Regras de validação para o login
const regrasLogin = [
  body('email').isEmail().withMessage('Email inválido').normalizeEmail(),
  body('password').notEmpty().withMessage('A palavra-passe é obrigatória'),
];

// POST /api/auth/register
router.post('/register', regrasRegisto, register);

// POST /api/auth/login
router.post('/login', regrasLogin, login);

module.exports = router;
