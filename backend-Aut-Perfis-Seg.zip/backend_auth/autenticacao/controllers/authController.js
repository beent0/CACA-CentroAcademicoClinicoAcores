const jwt  = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const User = require('../models/User');

/** Gera um token JWT assinado para o id do utilizador (expira em 7 dias) */
function gerarToken(id) {
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' });
}

/** Remove a password do objeto antes de enviar na resposta */
function sanitizar(user) {
  return {
    nome:      user.nome,
    email:     user.email,
    telemovel: user.telemovel,
    role:      user.role,
    bio:       user.bio,
  };
}

/**
 * POST /api/auth/register
 * Body: { nome, email, telemovel, password }
 */
exports.register = async (req, res) => {
  // Verificar erros de validação do express-validator
  const erros = validationResult(req);
  if (!erros.isEmpty()) {
    return res.status(422).json({ success: false, message: erros.array()[0].msg });
  }

  const { nome, email, telemovel, password } = req.body;

  try {
    // Verificar se o email já está registado
    if (await User.findOne({ email })) {
      return res.status(409).json({ success: false, message: 'Este email já está registado.' });
    }

    // Criar utilizador (a password é hasheada automaticamente pelo modelo)
    const utilizador = await User.create({ nome, email, telemovel, password });

    res.status(201).json({
      success: true,
      message: 'Utilizador registado com sucesso',
      token:   gerarToken(utilizador._id),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * POST /api/auth/login
 * Body: { email, password }
 */
exports.login = async (req, res) => {
  const erros = validationResult(req);
  if (!erros.isEmpty()) {
    return res.status(422).json({ success: false, message: erros.array()[0].msg });
  }

  const { email, password } = req.body;

  try {
    // Procurar utilizador e incluir a password (excluída por defeito no schema)
    const utilizador = await User.findOne({ email }).select('+password');

    if (!utilizador || !(await utilizador.comparePassword(password))) {
      return res.status(401).json({ success: false, message: 'Email ou palavra-passe incorretos.' });
    }

    res.status(200).json({
      success: true,
      token:   gerarToken(utilizador._id),
      user:    sanitizar(utilizador),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * GET /api/users/profile  (requer middleware protect)
 * Devolve os dados do utilizador autenticado.
 */
exports.getProfile = (req, res) => {
  res.status(200).json({
    success: true,
    user:    sanitizar(req.user),
  });
};

/**
 * PUT /api/users/profile  (requer middleware protect)
 * Body: { nome?, telemovel?, bio? }
 */
exports.updateProfile = async (req, res) => {
  const { nome, telemovel, bio } = req.body;

  try {
    const utilizador = await User.findByIdAndUpdate(
      req.user._id,
      {
        ...(nome      && { nome }),
        ...(telemovel !== undefined && { telemovel }),
        ...(bio       !== undefined && { bio }),
      },
      { new: true, runValidators: true }
    );

    res.status(200).json({
      success: true,
      message: 'Perfil atualizado',
      user:    sanitizar(utilizador),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
