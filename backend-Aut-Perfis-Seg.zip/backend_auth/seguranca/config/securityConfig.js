/**
 * securityConfig.js — Configuração de CORS e variáveis de ambiente
 *
 * Centraliza as opções de segurança para não ficarem dispersas pelo server.js.
 */

/**
 * Opções de CORS.
 *
 * O frontend do projeto usa Vite (porta 5173).
 * credentials: true — necessário para enviar o header Authorization.
 */
const corsOptions = {
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
};

/**
 * validateEnv — Verifica se as variáveis de ambiente obrigatórias estão definidas.
 * Chamada no arranque para evitar erros silenciosos em produção.
 */
function validateEnv() {
  const obrigatorias = ['MONGO_URI', 'JWT_SECRET'];
  const emFalta = obrigatorias.filter(key => !process.env[key]);

  if (emFalta.length > 0) {
    console.error(`❌ Variáveis de ambiente em falta: ${emFalta.join(', ')}`);
    console.error('   Copia .env.example para .env e preenche os valores.');
    process.exit(1);
  }

  console.log('✅ Variáveis de ambiente validadas');
}

module.exports = { corsOptions, validateEnv };
