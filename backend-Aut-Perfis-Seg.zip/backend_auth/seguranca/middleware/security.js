/**
 * security.js — Middlewares de segurança
 *
 * Implementa as proteções essenciais pedidas no enunciado:
 *   - CORS: restringe origens permitidas
 *   - Rate limiting: proteção contra brute force nas rotas de autenticação
 *   - Validação de inputs: feita via express-validator nas rotas (ver auth.js)
 *
 * Mantido simples e académico conforme diretriz do projeto.
 */

const rateLimit = require('express-rate-limit');

/**
 * authLimiter — Rate limiting para rotas de autenticação.
 *
 * Máximo de 10 tentativas de login/registo por IP a cada 15 minutos.
 * Dificulta ataques de brute force (adivinhar passwords por força bruta).
 *
 * skipSuccessfulRequests: true — logins bem-sucedidos não contam para o limite.
 */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // janela de 15 minutos
  max: 10,                   // máximo de 10 tentativas falhadas
  skipSuccessfulRequests: true,
  message: {
    success: false,
    message: 'Demasiadas tentativas. Tente novamente em 15 minutos.',
  },
});

module.exports = { authLimiter };
