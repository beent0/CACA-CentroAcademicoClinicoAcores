const jwt  = require('jsonwebtoken');
const User = require('../../autenticacao/models/User');

/**
 * protect — Verifica se o pedido tem um JWT válido.
 *
 * Lê o token do header Authorization: Bearer <token>
 * Se válido, anexa o utilizador a req.user e passa para o próximo middleware.
 * Se inválido ou em falta, devolve 401.
 */
async function protect(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Não autenticado. Token em falta.' });
  }

  const token = authHeader.split(' ')[1];

  try {
    // Verificar e descodificar o token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Procurar o utilizador correspondente na base de dados
    req.user = await User.findById(decoded.id);

    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Utilizador não encontrado.' });
    }

    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Token inválido ou expirado.' });
  }
}

/**
 * adminOnly — Garante que apenas administradores acedem à rota.
 *
 * Deve ser usado SEMPRE depois do middleware protect.
 * Se o utilizador não for admin, devolve 403.
 */
function adminOnly(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ success: false, message: 'Acesso negado. Apenas administradores.' });
  }
  next();
}

module.exports = { protect, adminOnly };
