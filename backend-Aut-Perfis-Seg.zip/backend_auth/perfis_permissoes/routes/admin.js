const express = require('express');
const router  = express.Router();
const { protect, adminOnly } = require('../middleware/auth');
const { getUsers, changeRole, deleteUser } = require('../controllers/adminController');

// Todas as rotas deste ficheiro requerem JWT válido E role admin
router.use(protect, adminOnly);

// GET  /api/admin/users           — listar todos os utilizadores
router.get('/users', getUsers);

// PUT  /api/admin/users/:id/role  — alterar role de um utilizador
router.put('/users/:id/role', changeRole);

// DELETE /api/admin/users/:id     — eliminar utilizador
router.delete('/users/:id', deleteUser);

module.exports = router;
