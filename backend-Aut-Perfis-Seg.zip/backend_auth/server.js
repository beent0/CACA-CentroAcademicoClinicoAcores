/**
 * server.js — Ponto de entrada da API CACA
 *
 * Integra os três módulos do backend:
 *   1. Segurança       (CORS, rate limiting)
 *   2. Autenticação    (register, login)
 *   3. Perfis/Permissões (perfil do utilizador, gestão admin)
 */

require('dotenv').config();

const express = require('express');
const cors    = require('cors');

const connectDB                   = require('./config/db');
const { corsOptions, validateEnv } = require('./seguranca/config/securityConfig');
const { authLimiter }              = require('./seguranca/middleware/security');
const authRoutes                   = require('./autenticacao/routes/auth');
const { protect }                  = require('./perfis_permissoes/middleware/auth');
const { getProfile, updateProfile } = require('./autenticacao/controllers/authController');
const adminRoutes                  = require('./perfis_permissoes/routes/admin');

// Validar .env antes de iniciar
validateEnv();

const app = express();

// ── Middlewares globais ───────────────────────────────────────────────────────
app.use(cors(corsOptions));
app.use(express.json());

// ── Base de dados ─────────────────────────────────────────────────────────────
connectDB();

// ── Rotas de autenticação (com rate limiting) ─────────────────────────────────
app.use('/api/auth/login',    authLimiter);
app.use('/api/auth/register', authLimiter);
app.use('/api/auth', authRoutes);

// ── Rotas de perfil (conforme contrato: /api/users/profile) ──────────────────
app.get('/api/users/profile', protect, getProfile);
app.put('/api/users/profile', protect, updateProfile);

// ── Rotas de administração ────────────────────────────────────────────────────
app.use('/api/admin', adminRoutes);

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ success: true, status: 'API a funcionar' }));

// ── Tratamento global de erros ────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Erro interno do servidor.' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 API a correr em http://localhost:${PORT}`));
